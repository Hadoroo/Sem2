public class UAP {
    /// NIM: 225150207111037
    ///NAMA: Hadi Kresnadi
    public static void main(String[] args) {
        Data.mulai();
        Data.info();
    }
}


