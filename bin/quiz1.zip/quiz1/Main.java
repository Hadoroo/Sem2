package quiz1;

public class Main {

    //Nama: Hadi Kresnadi
    //NIM: 225150207111037
    //Kelas: TIF C
    public static void main(String[] args) {
        int[][] graf = {   
        {0, 1, 0, 1, 0, 0, 0, 0},
        {1, 0, 1, 1, 0, 0, 1, 0},
        {0, 1, 0, 0, 0, 0, 0, 0},
        {1, 1, 0, 0, 1, 0, 0, 0},
        {0, 0, 0, 1, 0, 1, 0, 0},
        {0, 0, 0, 0, 1, 0, 0, 0},
        {0, 1, 0, 0, 0, 0, 0, 1},
        {0, 0, 0, 0, 0, 0, 1, 0},
    };

    int start = 0;
    int end = 4;

    Find find = new Find(graf, start, end);

    find.Pass();
    find.print();
    }
}
