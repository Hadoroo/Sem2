package quiz1;

class Node {
    int data;
    Node under;
    
    Node(int data){
        this.under = null;
        this.data = data;
    }
}
