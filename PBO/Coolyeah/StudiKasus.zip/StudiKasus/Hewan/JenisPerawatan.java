package StudiKasus.Hewan;

public enum JenisPerawatan{
    SUNTIK_VAKSIN,
    SUNTIK_ANTI_KUTU,
    SUNTIK_SCABIES,
    SUNTIK_ANTI_JAMUR_KULIT,
    PEMERIKSAAN_RAWAT_INAP,
    PEMERIKSAAN_RAWAT_JALAN,
    GROOMING;
}

 