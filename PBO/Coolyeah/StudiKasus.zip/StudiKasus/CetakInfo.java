package StudiKasus;

public interface CetakInfo {
    public void cetak();
}
