package StudiKasus;

public interface CetakInfoHewan {
    public void cetakHewan();
}
